package com.morningmusic.app.data.model

import java.io.Serializable

data class Track(
    val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val durationSeconds: Long,
    val coverUrl: String,
    val audioUrl: String,
    val language: String
) : Serializable
