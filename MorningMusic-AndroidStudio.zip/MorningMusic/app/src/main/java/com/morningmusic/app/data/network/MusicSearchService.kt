package com.morningmusic.app.data.network

import com.morningmusic.app.data.model.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Clean, provider-independent Android service to search and fetch songs from the secure backend proxy.
 * Can be easily configured or replaced with another music/audio provider later.
 */
object MusicSearchService {
    // Dynamic backend API proxy base URL
    private const val BACKEND_URL = "http://10.0.2.2:3000" // Fallback to Android emulator local host

    suspend fun searchSongs(query: String, language: String = "all"): List<Track> = withContext(Dispatchers.IO) {
        val tracks = mutableListOf<Track>()
        try {
            val encodedQuery = URLEncoder.encode(query, "UTF-8")
            val urlString = "$BACKEND_URL/api/youtube/search?q=$encodedQuery&language=$language"
            val connection = URL(urlString).openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 10000
            connection.readTimeout = 10000

            if (connection.responseCode == 200) {
                val response = connection.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(response)
                val items = json.optJSONArray("tracks") ?: return@withContext emptyList()
                for (i in 0 until items.length()) {
                    val item = items.getJSONObject(i)
                    val id = item.optString("id")
                    val title = item.optString("title")
                    val artist = item.optString("artist")
                    val album = item.optString("album", "Single")
                    val duration = item.optLong("duration", 180)
                    val coverUrl = item.optString("coverUrl")
                    val audioUrl = item.optString("audioUrl")
                    val lang = item.optString("language", "english")

                    tracks.add(
                        Track(
                            id = id,
                            title = title,
                            artist = artist,
                            album = album,
                            durationSeconds = duration,
                            coverUrl = coverUrl,
                            audioUrl = audioUrl,
                            language = lang
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        tracks
    }
}
