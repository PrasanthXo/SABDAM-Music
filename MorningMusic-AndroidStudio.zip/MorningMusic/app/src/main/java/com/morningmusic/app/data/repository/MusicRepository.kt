package com.morningmusic.app.data.repository

import com.morningmusic.app.data.model.Track

object MusicRepository {

    val popularTamil = listOf(
        Track(
            id = "tamil-1",
            title = "Theerthakkaraiyinile",
            artist = "K. J. Yesudas",
            album = "Classic Carnatic Hits",
            durationSeconds = 278,
            coverUrl = "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=600",
            audioUrl = "https://archive.org/download/Theerthakkaraiyinile_201511/Theerthakkaraiyinile.mp3",
            language = "Tamil"
        ),
        Track(
            id = "tamil-2",
            title = "Aagaya Thamarai",
            artist = "Ilaiyaraaja, S. Janaki",
            album = "Ilayaraja Golden Melodies",
            durationSeconds = 295,
            coverUrl = "https://images.unsplash.com/photo-1465847899084-d164df4dedc6?w=600",
            audioUrl = "https://archive.org/download/IlayarajaMelodies/Aagaya%20Thamarai.mp3",
            language = "Tamil"
        ),
        Track(
            id = "tamil-3",
            title = "Aasai Oru Pulveli",
            artist = "A. R. Rahman, Sujatha",
            album = "Poo Pookum Oosai",
            durationSeconds = 219,
            coverUrl = "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=600",
            audioUrl = "https://archive.org/download/PooPookumOssai_201701/AASAI%20ORU%20PULVELI.mp3",
            language = "Tamil"
        )
    )

    val popularEnglish = listOf(
        Track(
            id = "english-1",
            title = "Sunrise Horizon",
            artist = "The Midnight Groove",
            album = "Chilled Dawn Sessions",
            durationSeconds = 372,
            coverUrl = "https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=600",
            audioUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
            language = "English"
        ),
        Track(
            id = "english-2",
            title = "Velvet Skyline",
            artist = "Acoustic Ember",
            album = "Echoes in the Light",
            durationSeconds = 423,
            coverUrl = "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=600",
            audioUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
            language = "English"
        )
    )

    val trending = listOf(popularTamil[2], popularEnglish[0])
    val newReleases = listOf(popularEnglish[1], popularTamil[1])
}
