package com.morningmusic.app.ui.viewmodel

import android.app.Application
import android.content.ComponentName
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.morningmusic.app.data.model.Track
import com.morningmusic.app.data.repository.MusicRepository
import com.morningmusic.app.data.network.MusicSearchService
import com.morningmusic.app.service.PlaybackService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.Job
import java.util.Calendar

/**
 * Architecture: Unidirectional Data Flow ViewModel with strictly time-based greeting logic and extensible music searching.
 * Integrates natively with Android Media3 PlaybackService to support robust, continuous background playback
 * and lock screen controls when the device display is switched off.
 */
class MusicViewModel(application: Application) : AndroidViewModel(application) {

    private val _currentTrack = MutableStateFlow<Track?>(null)
    val currentTrack: StateFlow<Track?> = _currentTrack.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentPosition = MutableStateFlow(0L)
    val currentPosition: StateFlow<Long> = _currentPosition.asStateFlow()

    private val _likedTrackIds = MutableStateFlow<Set<String>>(setOf("tamil-3", "english-1"))
    val likedTrackIds: StateFlow<Set<String>> = _likedTrackIds.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _searchResults = MutableStateFlow<List<Track>>(emptyList())
    val searchResults: StateFlow<List<Track>> = _searchResults.asStateFlow()

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()

    private val _suggestions = MutableStateFlow<List<String>>(emptyList())
    val suggestions: StateFlow<List<String>> = _suggestions.asStateFlow()

    val popularTamil = MusicRepository.popularTamil
    val popularEnglish = MusicRepository.popularEnglish
    val trending = MusicRepository.trending
    val newReleases = MusicRepository.newReleases

    private var lastSearchJob: Job? = null
    private var mediaController: MediaController? = null
    private var controllerFuture: ListenableFuture<MediaController>? = null

    init {
        _currentTrack.value = popularTamil.firstOrNull()

        // Asynchronously initialize modern Jetpack Media3 MediaController
        try {
            val sessionToken = SessionToken(
                application,
                ComponentName(application, PlaybackService::class.java)
            )
            controllerFuture = MediaController.Builder(application, sessionToken).buildAsync()
            controllerFuture?.addListener({
                try {
                    val controller = controllerFuture?.get()
                    mediaController = controller
                    if (controller != null) {
                        _isPlaying.value = controller.isPlaying
                        
                        // Keep state of isPlaying and currentPosition in sync with controller
                        viewModelScope.launch {
                            while (true) {
                                _currentPosition.value = controller.currentPosition
                                _isPlaying.value = controller.isPlaying
                                delay(1000)
                            }
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }, { command -> command?.run() })
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * STRICT REQUIREMENT:
     * NEVER display the user's name anywhere.
     * Automatically show only one greeting based on current local time:
     * 5:00 AM–11:59 AM → "Good morning"
     * 12:00 PM–5:59 PM → "Good afternoon"
     * 6:00 PM–4:59 AM → "Good night"
     */
    fun getTimeGreeting(): String {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when {
            hour in 5..11 -> "Good morning"
            hour in 12..17 -> "Good afternoon"
            else -> "Good night"
        }
    }

    fun onSearchQueryChange(query: String) {
        _searchQuery.value = query
        val trimmed = query.trim()
        if (trimmed.isEmpty()) {
            _searchResults.value = emptyList()
            _suggestions.value = emptyList()
            return
        }

        // Generate similar word suggestions with at least 5 results
        _suggestions.value = generateSuggestions(trimmed)

        lastSearchJob?.cancel()
        lastSearchJob = viewModelScope.launch {
            _isSearching.value = true
            // Debounce for 500ms before making remote proxy API request
            delay(500)
            val results = MusicSearchService.searchSongs(query)
            _searchResults.value = results
            _isSearching.value = false
        }
    }

    private fun generateSuggestions(query: String): List<String> {
        val qLower = query.lowercase().trim()
        if (qLower.isEmpty()) return emptyList()

        val results = mutableListOf<String>()

        // Gather track titles, artists and albums from local MusicRepository
        val allCatalog = popularTamil + popularEnglish + trending + newReleases
        val wordsSet = mutableSetOf<String>()
        for (t in allCatalog) {
            wordsSet.add(t.title)
            wordsSet.add(t.artist)
            t.album?.let { wordsSet.add(it) }

            // Extract individual words of length > 2
            val parts = "${t.title} ${t.artist} ${t.album ?: ""}"
                .split(Regex("[\\s(),\\-:._+]+"))
                .map { it.trim() }
                .filter { it.length > 2 }
            for (p in parts) {
                wordsSet.add(p)
            }
        }

        val allWords = wordsSet.toList()

        // 1. Prefix matches (starts with typed letters)
        val startMatches = allWords.filter { it.lowercase().startsWith(qLower) }
        for (w in startMatches) {
            if (results.size >= 5) break
            if (!results.any { it.equals(w, ignoreCase = true) }) {
                results.add(w)
            }
        }

        // 2. Substring matches (contains typed letters)
        if (results.size < 5) {
            val containMatches = allWords.filter { it.lowercase().contains(qLower) }
            for (w in containMatches) {
                if (results.size >= 5) break
                if (!results.any { it.equals(w, ignoreCase = true) }) {
                    results.add(w)
                }
            }
        }

        // 3. Defaults backfill to ensure at least 5 suggestions are always returned
        val defaults = listOf("Manja Balloon", "Kaavaalaa", "Hukum", "Chuttamalle", "Katchi Sera")
        if (results.size < 5) {
            for (d in defaults) {
                if (results.size >= 5) break
                if (!results.any { it.equals(d, ignoreCase = true) }) {
                    results.add(d)
                }
            }
        }

        return results.take(8)
    }

    fun playTrack(track: Track) {
        _currentTrack.value = track
        _isPlaying.value = true
        _currentPosition.value = 0L

        mediaController?.let { controller ->
            val rawUrl = track.audioUrl ?: ""
            // Detect and route YouTube requests through the secure proxy stream redirections
            val streamUrl = if (rawUrl.startsWith("yt:") || rawUrl.startsWith("yt-") || track.id.startsWith("yt-")) {
                val videoId = rawUrl.replace("yt:", "").replace("yt-", "").ifEmpty { track.id.replace("yt-", "") }
                // In emulator, http://10.0.2.2:3000 proxies requests to the server running on localhost:3000
                "http://10.0.2.2:3000/api/youtube/stream?id=$videoId"
            } else {
                rawUrl
            }

            if (streamUrl.isNotEmpty()) {
                val mediaItem = MediaItem.fromUri(streamUrl)
                controller.stop()
                controller.setMediaItem(mediaItem)
                controller.prepare()
                controller.play()
            }
        }
    }

    fun togglePlayPause() {
        mediaController?.let { controller ->
            if (controller.isPlaying) {
                controller.pause()
                _isPlaying.value = false
            } else {
                controller.play()
                _isPlaying.value = true
            }
        } ?: run {
            _isPlaying.value = !_isPlaying.value
        }
    }

    fun toggleLike(trackId: String) {
        val current = _likedTrackIds.value.toMutableSet()
        if (current.contains(trackId)) {
            current.remove(trackId)
        } else {
            current.add(trackId)
        }
        _likedTrackIds.value = current
    }

    override fun onCleared() {
        super.onCleared()
        controllerFuture?.let { future ->
            MediaController.releaseFuture(future)
        }
    }
}
